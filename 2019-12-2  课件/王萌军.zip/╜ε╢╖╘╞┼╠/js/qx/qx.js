// console.log($input)
$input.click(function(){ // 全选
    const divss = document.querySelectorAll('.folder');
    console.log(divss)
    if($(this)[0].checked === true){
          divss.forEach((item)=>{
              item.style.background = 'pink';
          })
    }else{
     divss.forEach((item)=>{
         item.style.background = '#fff';
     })
    }
})

// document.onclick = function(){
//     const divsss = document.querySelectorAll('.folder')
//     divsss.forEach(item=>{
//         item.style.background = '#fff';
//     })
// }
