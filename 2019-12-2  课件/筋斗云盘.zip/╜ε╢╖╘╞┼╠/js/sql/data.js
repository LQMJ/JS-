var data = {
    "0": {
        "id": 0,
        "pid": -1,
        "title": "我的云盘",
        "type": "file",
        "checked":false
    },
    "1": {
        "id": 1,
        "pid": 0,
        "title": "我的文档",
        "type": "file",
        "checked":false
    },
    "11": {
        "id": 11,
        "pid": 1,
        "title": "js权威指南",
        "type": "file",
        "checked":false
    },
    "12": {
        "id": 12,
        "pid": 1,
        "title": "js程序设计",
        "type": "file",
        "checked":false
    },
    "2": {
        "id": 2,
        "pid": 0,
        "title": "我的图片",
        "checked":false
    },
    "3": {
        "id": 3,
        "pid": 0,
        "title": "我的视频",
        "checked":false
    },
    "4": {
        "id": 4,
        "pid": 0,
        "title": "我的音乐",
        "checked":false
    },
    "41": {
        "id": 41,
        "pid": 4,
        "title": "林俊杰",
        "checked":false
    },
    "411": {
        "id": 411,
        "pid": 41,
        "title": "江南",
        "checked":false
    },
    "412": {
        "id": 412,
        "pid": 41,
        "title": "醉赤壁",
        "checked":false
    },
    "413": {
        "id": 413,
        "pid": 41,
        "title": "修炼爱情",
        "checked":false
    },
    "42": {
        "id": 42,
        "pid": 4,
        "title": "周杰伦",
        "checked":false
    },
    "421": {
        "id": 421,
        "pid": 42,
        "title": "青花瓷",
        "checked":false
    },
    "422": {
        "id": 422,
        "pid": 42,
        "title": "稻香",
        "checked":false
    },
    "423": {
        "id": 423,
        "pid": 42,
        "title": "告白气球",
        "checked":false
    },
    "43": {
        "id": 43,
        "pid": 4,
        "title": "张杰",
        "checked":false
    },
    "431": {
        "id": 431,
        "pid": 43,
        "title": "天下",
        "checked":false
    },
    "432": {
        "id": 432,
        "pid": 43,
        "title": "逆战",
        "checked":false
    },
    "433": {
        "id": 433,
        "pid": 43,
        "title": "明天过后",
        "checked":false
    }
}